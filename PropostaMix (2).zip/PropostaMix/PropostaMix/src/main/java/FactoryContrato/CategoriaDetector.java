package FactoryContrato;

import FactoryContrato.clausulas.CategoriaEquipamento;

public class CategoriaDetector {
    
    public static CategoriaEquipamento detectar(String nomeItem) {

        String n = nomeItem.toLowerCase();

        if (n.contains("som") || n.contains("audio") || n.contains("caixa")) {
            return CategoriaEquipamento.AUDIO;
        }

        if (n.contains("luz") || n.contains("iluminação") || n.contains("moving")) {
            return CategoriaEquipamento.ILUMINACAO;
        }

        if (n.contains("led") || n.contains("painel")) {
            return CategoriaEquipamento.LED;
        }

        if (n.contains("palco") || n.contains("estrutura") || n.contains("grid")) {
            return CategoriaEquipamento.ESTRUTURA;
        }

        return CategoriaEquipamento.OUTROS;
    }
}
