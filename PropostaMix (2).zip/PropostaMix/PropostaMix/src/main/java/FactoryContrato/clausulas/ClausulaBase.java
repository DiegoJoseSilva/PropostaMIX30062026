package FactoryContrato.clausulas;

import FactoryContrato.Clausula;
import Model.Orcamento;

public class ClausulaBase implements Clausula {
     @Override
    public String gerar(Orcamento o) {
        return """
        CLÁUSULA GERAL:

        - O cliente é responsável pela segurança do local
        - Danos por uso inadequado serão cobrados
        - Cancelamento segue política da empresa
        """;
    }
}
