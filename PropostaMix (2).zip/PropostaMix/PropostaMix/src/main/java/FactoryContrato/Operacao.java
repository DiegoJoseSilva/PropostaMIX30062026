package FactoryContrato;

import Model.Orcamento;

public class Operacao implements Clausula {
     @Override
    public String gerar(Orcamento o) {
        return """
        CLÁUSULA - SISTEMA DE ÁUDIO

        A LOCATÁRIA deverá fornecer:
        - Energia estável (110V ou 220V)
        - Rede com aterramento adequado
        - Pontos suficientes para o sistema de áudio

        Danos por energia inadequada serão de responsabilidade da LOCATÁRIA.
        """;
    }
}
