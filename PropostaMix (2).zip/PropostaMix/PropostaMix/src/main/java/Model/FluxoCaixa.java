package Model;

import java.time.LocalDate;

public class FluxoCaixa {

    
        private Integer id;
        private Integer orcamentoId;
        private LocalDate dataLancamento;
        private String descricao;
        private double valor;
        private TipoMovimentacao tipo;
        private String nomeEvento;
        private String nomeCliente;
        
        public String getNomeEvento() {
            return nomeEvento;
        }


        public void setNomeEvento(String nomeEvento) {
            this.nomeEvento = nomeEvento;
        }


        public String getNomeCliente() {
            return nomeCliente;
        }


        public void setNomeCliente(String nomeCliente) {
            this.nomeCliente = nomeCliente;
        }
        
        public void setId(Integer id) {
            this.id = id;
        }

        public Integer getOrcamentoId() {
            return orcamentoId;
        }

        public void setOrcamentoId(Integer orcamentoId) {
            this.orcamentoId = orcamentoId;
        }   
    
        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.setId((Integer) id);
        }

        public LocalDate getDataLancamento() {
            return dataLancamento;
        }

        public void setDataLancamento(LocalDate dataLancamento) {
            this.dataLancamento = dataLancamento;
        }

        public String getDescricao() {
            return descricao;
        }

        public void setDescricao(String descricao) {
            this.descricao = descricao;
        }

        public Double getValor() {
            return valor;
        }

        public void setValor(Double valor) {
            this.valor = valor;
        }

        public TipoMovimentacao getTipo() {
            return tipo;
        }

        public void setTipo(TipoMovimentacao tipo) {
            this.tipo = tipo;
        }
    
}
