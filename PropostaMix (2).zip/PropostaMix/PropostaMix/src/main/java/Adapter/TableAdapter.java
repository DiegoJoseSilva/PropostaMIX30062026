package Adapter;

public interface TableAdapter {
    Object[] toRow();
}
