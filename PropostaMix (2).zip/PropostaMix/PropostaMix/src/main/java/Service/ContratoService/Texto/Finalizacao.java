package Service.ContratoService.Texto;

import Model.Orcamento;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Finalizacao {

    public String gerar(Orcamento o) {

        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("dd/MM/yyyy");

        return """
               11. FORO

               Fica eleito o foro da comarca de Patrocínio/MG.

               ASSINATURAS

               Patrocínio/MG, %s.

               LOCADORA:
               JOSE CARLOS DA SILVA
               CNPJ: 19.103.297/0001-49

               Assinatura: __________________________

               LOCATÁRIA:
               %s

               CPF: %s

               Assinatura: __________________________
               """
                .formatted(
                        LocalDate.now().format(formatter),
                        o.getCliente().getNome(),
                        o.getCliente().getCpfCnpj()
                );
    }
}
