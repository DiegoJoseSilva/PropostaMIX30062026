package Service.ContratoService.Texto;

import Model.Orcamento;
import java.time.format.DateTimeFormatter;


public class DataLocalPrazo implements SecaoContrato{
    @Override
    public String gerar(Orcamento o) {

        StringBuilder sb = new StringBuilder();

        sb.append("""
                
                4. DATA, LOCAL E PRAZO DE LOCAÇÃO

                """);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        sb.append("Data: ").append(o.getEvento().getDataEvento().format(formatter)).append("\n");

        sb.append("Hora de início: ").append(o.getEvento().getHorario()).append("\n");

        sb.append("Local: ").append(o.getEvento().getLocalEvento()).append(" - ").append(o.getEvento().getCidade()).append("\n\n");

        sb.append("""
                A montagem será realizada previamente em horário alinhado entre as partes.
                O sistema permanecerá disponível no evento por até 8 horas.
                A desmontagem ocorrerá após o término.
                Parágrafo primeiro — A permanência do sistema após o horário estipulado implicará cobrança adicional de 7% por hora excedente, mediante disponibilidade técnica da LOCADORA.
                Parágrafo segundo — Atrasos no início do evento não alteram o horário final da locação.
                """);

        return sb.toString();
    }
}
