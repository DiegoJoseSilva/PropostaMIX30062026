package Service.ContratoService.Texto;

import Model.Orcamento;

public class ValorContrato implements SecaoContrato {
    @Override
    public String gerar(Orcamento o) {

        StringBuilder sb = new StringBuilder();

        sb.append("""
                
                5. VALOR DO CONTRATO

                """);

        sb.append("O valor total da locação é de R$ ")
          .append(String.format("%.2f", o.getValorTotal()))
          .append(".\n");

        sb.append("Forma de pagamento: ")
          .append(o.getFormaPagamento())
          .append(".\n\n");

        return sb.toString();
    }
}
