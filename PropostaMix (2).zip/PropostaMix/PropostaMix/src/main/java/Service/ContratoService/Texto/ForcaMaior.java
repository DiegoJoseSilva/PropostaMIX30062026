package Service.ContratoService.Texto;

import Model.Orcamento;

public class ForcaMaior implements SecaoContrato{
    @Override
    public String gerar(Orcamento o) {

        return """
                
                9. FORÇA MAIOR

                A LOCADORA não será responsável por falhas decorrentes de:
                - Chuva extrema
                - Falta de energia pública
                - Interdição do local
                - Determinação de autoridades

                """;
    }
}
