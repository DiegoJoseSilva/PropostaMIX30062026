package Service.ContratoService.Texto;

import Model.Orcamento;

public class IdentificacaoPartes implements SecaoContrato {

    @Override
    public String gerar(Orcamento o) {

        return """
               1. IDENTIFICAÇÃO DAS PARTES

               LOCADORA:
               JOSE CARLOS DA SILVA, inscrita no CNPJ nº 19.103.297/0001-49,
               doravante denominada LOCADORA.

               LOCATÁRIA:
               %s, inscrita no CPF %s, residente/domiciliado em %s,
               doravante denominada LOCATÁRIA.

               """
                .formatted(
                        o.getCliente().getNome(),
                        o.getCliente().getCpfCnpj(),
                        o.getCliente().getEndereco()
                );
    }
}
