package Service.ContratoService.Texto;

import Model.Orcamento;

public class DisposicoesGerais implements SecaoContrato{
    @Override
    public String gerar(Orcamento o) {

        return """
                
                10. DISPOSIÇÕES GERAIS

                Alterações devem ser formalizadas por ambas as partes.
                Itens extras serão cobrados à parte.
                O sistema será operado por técnico da LOCADORA.

                """;
    }
}
