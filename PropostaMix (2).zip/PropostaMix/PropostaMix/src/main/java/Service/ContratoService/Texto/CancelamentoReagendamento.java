package Service.ContratoService.Texto;

import Model.Orcamento;

public class CancelamentoReagendamento implements SecaoContrato {
    @Override
    public String gerar(Orcamento o) {

        return """
                
                8. CANCELAMENTO E REAGENDAMENTO

                Em caso de cancelamento por parte da LOCATÁRIA:
                Será aplicada multa de 50% do valor do contrato.

                Reagendamento:
                Prazo mínimo de 20 dias, sujeito à disponibilidade.
                Possível ajuste de valores.

                """;
    }
}
