package Service.ContratoService.Texto;

import Model.Orcamento;

public class ObjetoDoContrato implements SecaoContrato {
    @Override
    public String gerar(Orcamento o) {

        return """
               2. OBJETO DO CONTRATO

               O presente contrato tem como objeto a locação de equipamentos
               para realização do evento %s.

               """
               .formatted(
                       o.getEvento().getNome()
               );
    }
}
