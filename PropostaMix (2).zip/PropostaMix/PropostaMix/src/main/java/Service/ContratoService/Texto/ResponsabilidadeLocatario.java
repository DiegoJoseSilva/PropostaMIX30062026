package Service.ContratoService.Texto;

import Model.Orcamento;
import FactoryContrato.Clausula;
import FactoryContrato.ClausulaFactory;
import java.util.List;

public class ResponsabilidadeLocatario implements SecaoContrato{
    @Override
    public String gerar(Orcamento o) {

        StringBuilder sb = new StringBuilder();

        sb.append("""
                7. RESPONSABILIDADE DO LOCATÁRIO

                A LOCATÁRIA será responsável por:
                - Segurança dos equipamentos
                - Danos, furtos, roubos ou extravios
                - Uso inadequado por terceiros
                - Danos causados por bebidas, chuva ou mau uso
                - Custos de reposição ou reparo

                """);

        //aqui chama a factory, visto que se tiver algum item com especificidade ele inclui a clausula 
        List<Clausula> extras = ClausulaFactory.criar(o);

        for (Clausula c : extras) {
            sb.append(c.gerar(o));
        }

        sb.append("\n");

        return sb.toString();
    }
}
