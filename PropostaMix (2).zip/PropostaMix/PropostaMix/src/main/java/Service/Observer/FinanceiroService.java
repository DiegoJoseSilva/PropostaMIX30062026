package Service.Observer;

import DAO.OrcamentoDAO;
import Model.Orcamento;
import Model.StatusPagamento;

public class FinanceiroService {
    
    private final OrcamentoNotifier notifier = new OrcamentoNotifier();

    public void confirmarPagamento(Orcamento orcamento) {
        OrcamentoDAO dao = new OrcamentoDAO();

        orcamento.setStatus(StatusPagamento.PAGO);

        dao.atualizar(orcamento);

        notifier.notificar(orcamento);
    }
}
