package Service.Observer;

import Model.Orcamento;

public interface OrcamentoSubject {
    void adicionarObserver(OrcamentoObserver observer);

     void removerObserver(OrcamentoObserver observer);

     void notificarObservers(Orcamento orcamento);
}
