package Service.Observer;

interface OrcamentoObserver {
     void atualizar(int idOrcamento);
}
