package Service.Observer;

import DAO.FluxoCaixaDAO;
import DAO.OrcamentoDAO;
import Model.FluxoCaixa;
import Model.Orcamento;
import Model.TipoMovimentacao;
import java.time.LocalDate;

public class FluxoCaixaObserver  implements OrcamentoObserver {
    
    @Override
    public void atualizar(int idOrcamento) {

        OrcamentoDAO dao = new OrcamentoDAO();
        FluxoCaixaDAO fluxoDAO = new FluxoCaixaDAO();

        Orcamento orcamento = dao.buscarPorId(idOrcamento);

        if (fluxoDAO.existeLancamentoPorOrcamento(idOrcamento)) {
            return;
        }

        FluxoCaixa fluxo = new FluxoCaixa();

        fluxo.setOrcamentoId(idOrcamento);
        fluxo.setDataLancamento(LocalDate.now());
        fluxo.setDescricao("Recebimento do orçamento " + idOrcamento);
        fluxo.setValor(orcamento.getValorTotal());
        fluxo.setTipo(TipoMovimentacao.RECEITA);

        fluxoDAO.salvar(fluxo);     
    }
}
