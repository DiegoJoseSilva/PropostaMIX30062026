package DAO;

import Model.Item;
import Model.ItemOrcamento;
import Util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemOrcamentoDAO {

    Connection conn;

    public ItemOrcamentoDAO() {
        conn = new Conexao().conectar();
    }

    public boolean salvar(ItemOrcamento item) {

        try {

            PreparedStatement stmt =
                    conn.prepareStatement(
                            """
                            INSERT INTO orcamento_item
                            (
                                orcamento_id,
                                item_id,
                                quantidade,
                                valor_unitario,
                                subtotal
                            )
                            VALUES (?, ?, ?, ?, ?)
                            """
                    );

            stmt.setInt(
                    1,
                    item.getOrcamento().getId());

            stmt.setInt(
                    2,
                    item.getItem().getId());

            stmt.setInt(
                    3,
                    item.getQuantidade());

            stmt.setDouble(
                    4,
                    item.getValorUnitario());

            stmt.setDouble(
                    5,
                    item.getSubtotal());

            stmt.executeUpdate();

            return true;

        } catch (SQLException ex) {

            ex.printStackTrace();
            return false;
        }
    }
    
    public List<ItemOrcamento> listarPorOrcamento(int idOrcamento) {

        List<ItemOrcamento> itens = new ArrayList<>();

        try {

            PreparedStatement stmt = conn.prepareStatement("""
                SELECT 
                    io.id AS io_id,
                    io.quantidade,
                    io.valor_unitario,
                    io.subtotal,
                    io.item_id,

                    i.id AS item_id_pk,
                    i.nome,
                    i.categoria
                FROM item_orcamento io
                INNER JOIN item i ON io.item_id = i.id
                WHERE io.orcamento_id = ?
                ORDER BY io.id
            """);

            stmt.setInt(1, idOrcamento);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                
                Item item = new Item();
                item.setId(rs.getInt("item_id_pk"));
                item.setNome(rs.getString("nome"));
                item.setCategoria(rs.getString("categoria"));

                ItemOrcamento io = new ItemOrcamento();
                io.setId(rs.getInt("io_id"));
                io.setItem(item);
                io.setQuantidade(rs.getInt("quantidade"));
                io.setValorUnitario(rs.getDouble("valor_unitario"));
                io.setSubtotal(rs.getDouble("subtotal"));

                itens.add(io);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return itens;
    }
}
