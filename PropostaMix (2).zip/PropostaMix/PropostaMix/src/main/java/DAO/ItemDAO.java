package DAO;

import Model.Item;
import Util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {
    
    Connection conn;
    
    public ItemDAO() {
            conn = new Conexao().conectar();
    }
    
    public Item salvar(Item i) {
        
         try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO item(nome, descricao, valor, categoria) values(?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, i.getNome());
            stmt.setString(2, i.getDescricao());
            stmt.setDouble(3, i.getValor());
            stmt.setString(4, i.getCategoria());
           
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                i.setId(rs.getInt("id"));
            }
            else{
                i.setId(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return i;      
    }
    
    public void editar(Item item) {
        
        try {
            PreparedStatement ppStmt = conn.prepareStatement(
                "UPDATE item SET nome=?, descricao=?, valor=?, categoria=? WHERE id=?"
            );

            ppStmt.setString(1, item.getNome());
            ppStmt.setString(2, item.getDescricao());
            ppStmt.setDouble(3, item.getValor());
            ppStmt.setString(4, item.getCategoria());
            ppStmt.setInt(5, item.getId());

            ppStmt.executeUpdate();

        } catch(SQLException ex){
            ex.printStackTrace();
        }   
    }
    
    public List<Item> buscarItens(Item item) {

        List<Item> lstItem = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM item where nome ILIKE ?", Statement.RETURN_GENERATED_KEYS);
            ppStmt.setString(1, item.getNome()+ "%");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstItem.add(getItem(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstItem;
        
    }

    public List<Item> buscarItens() {
        List<Item> lstItem = new ArrayList();
        
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM item", Statement.RETURN_GENERATED_KEYS);
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstItem.add(getItem(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstItem;
    }
    
    private Item getItem(ResultSet rs) throws SQLException {
        
        Item i = new Item();
        i.setId(rs.getInt("id"));
        i.setNome(rs.getString("nome"));
        i.setDescricao(rs.getString("descricao"));
        i.setValor(rs.getDouble("valor"));
        i.setCategoria(rs.getString("categoria"));
        return i;
    }   

    public int excluirItem(Item i) {
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM item where id= ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, i.getId());
            verif = stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                i.setId(rs.getInt("id"));
            }
            else{
                i.setId(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
}
