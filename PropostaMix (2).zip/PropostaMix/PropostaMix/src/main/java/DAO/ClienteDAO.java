package DAO;

import Model.Cliente;
import Util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class ClienteDAO {
    Connection conn;
    
    public ClienteDAO() {
            conn = new Conexao().conectar();
    }
    
    public Cliente salvar(Cliente c) {   
        
         try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO cliente(nome, cpf_cnpj, telefone, email, endereco) values(?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getCpfCnpj());
            stmt.setString(3, c.getTelefone());
            stmt.setString(4, c.getEmail());
            stmt.setString(5, c.getEndereco());
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                c.setId(rs.getInt(1));
            }
            else{
                c.setId(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return c;      
    }
    
    public boolean editar(Cliente cliente) {
       try {
            PreparedStatement ppStmt = conn.prepareStatement(
                "UPDATE cliente SET nome=?, cpf_cnpj=?, telefone=?, email=?, endereco=? WHERE id=?"
            );

            ppStmt.setString(1, cliente.getNome());
            ppStmt.setString(2, cliente.getCpfCnpj());
            ppStmt.setString(3, cliente.getTelefone());
            ppStmt.setString(4, cliente.getEmail());
            ppStmt.setString(5, cliente.getEndereco());
            ppStmt.setInt(6, cliente.getId());

            ppStmt.executeUpdate();
            
            return true;
        } catch(SQLException ex){
            ex.printStackTrace();
            return false;
        }   
    }
    
    public int excluir(Cliente c) {
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM cliente where id= ?", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, c.getId());
            verif = stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                c.setId(rs.getInt("id"));
            }
            else{
                c.setId(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }

    public List<Cliente> getList() {
        List<Cliente> lstC = new ArrayList();
        
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM cliente", Statement.RETURN_GENERATED_KEYS);
            
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstC.add(getCliente(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstC;
    }
    
    
    public List<Cliente> buscarClientes(Cliente cliente) {
        List<Cliente> lstCliente = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT *FROM cliente where nome ILIKE ?", Statement.RETURN_GENERATED_KEYS);
            ppStmt.setString(1, cliente.getNome()+ "%");
            
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstCliente.add(getCliente(rs));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return lstCliente;
    }
    
    public Cliente buscarPorId(int id) {
        String sql = "SELECT * FROM cliente WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Cliente cliente = new Cliente();

                    cliente.setId(rs.getInt("id"));
                    cliente.setNome(rs.getString("nome"));
                    cliente.setCpfCnpj(rs.getString("cpf_cnpj"));
                    cliente.setTelefone(rs.getString("telefone"));
                    cliente.setEmail(rs.getString("email"));
                    cliente.setEndereco(rs.getString("endereco"));

                    return cliente;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
    
    public List<Cliente> listarTodos() {

        List<Cliente> lista = new ArrayList<>();

        try {

            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM cliente ORDER BY nome");

            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {

                Cliente c = new Cliente();

                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                c.setCpfCnpj(rs.getString("cpf_cnpj"));
                c.setTelefone(rs.getString("telefone"));
                c.setEmail(rs.getString("email"));
                c.setEndereco(rs.getString("endereco"));

                lista.add(c);
            }

        } catch(SQLException ex) {
            ex.printStackTrace();
        }

        return lista;
    }
    
    
    private Cliente getCliente(ResultSet rs) throws SQLException {

        Cliente c = new Cliente();

        c.setId(rs.getInt("id"));
        c.setNome(rs.getString("nome"));
        c.setCpfCnpj(rs.getString("cpf_cnpj"));
        c.setEmail(rs.getString("email"));
        c.setEndereco(rs.getString("endereco"));
        c.setTelefone(rs.getString("telefone"));

        return c;
    } 
}
