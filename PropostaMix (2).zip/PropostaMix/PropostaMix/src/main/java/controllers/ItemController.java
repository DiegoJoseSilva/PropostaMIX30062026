package controllers;


import DAO.ItemDAO;
import Model.Cliente;
import Model.Item;
import java.util.List;

public class ItemController {
    ItemDAO iDAO = new ItemDAO();
    public void salvarItem(String nome, String descricao, Double valor, String categoria) {

        Item item = new Item();

        item.setNome(nome);
        item.setDescricao(descricao);
        item.setValor(valor);
        item.setCategoria(categoria);

        iDAO.salvar(item);
    }
    
    public void editarItem(Item item){  
        iDAO.editar(item);
    }
    
    public List<Item> buscarItens(Item item){
        return iDAO.buscarItens(item);
    }

    public int excluir(Item item) {
        return iDAO.excluirItem(item);
    }
    
}
