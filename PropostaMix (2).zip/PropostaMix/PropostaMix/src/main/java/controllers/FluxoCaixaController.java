package controllers;

import DAO.FluxoCaixaDAO;
import Model.FluxoCaixa;
import java.time.LocalDate;
import java.util.List;

public class FluxoCaixaController {
    private FluxoCaixaDAO dao;
    private OrcamentoController orcamentoController = new OrcamentoController();

    public FluxoCaixaController() {
        dao = new FluxoCaixaDAO();
    }

    public List<FluxoCaixa> filtrarPorPeriodo(LocalDate inicio, LocalDate fim) {
        return dao.filtrarPorPeriodo(inicio, fim);
    }
    
    public List<FluxoCaixa> listarTodos() {
        return dao.listarTodos();
    }
    
    public boolean excluir(int id) {
        return dao.excluir(id);
    }
    
    public boolean cancelarLancamento(int idFluxo, int idOrcamento) {

        // Cancela o orçamento
        boolean orcamentoCancelado = orcamentoController.cancelar(idOrcamento);

        if (!orcamentoCancelado) {
            return false;
        }

        // Exclui o lançamento do fluxo
        return dao.excluir(idFluxo);
    }
}
