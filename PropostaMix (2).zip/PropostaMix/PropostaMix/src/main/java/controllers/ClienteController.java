package controllers;

import DAO.ClienteDAO;
import Model.Cliente;
import java.util.List;

public class ClienteController {
    
    ClienteDAO cDAO = new ClienteDAO();
    
    public Cliente salvarCliente(Cliente cliente) {
           return cDAO.salvar(cliente);
    }
    
    public boolean editarCliente(Cliente cliente){
        return cDAO.editar(cliente);
    }
    
    public int excluir(Cliente cliente) {
          return cDAO.excluir(cliente);
    }
    
    public List<Cliente> buscarClientes(Cliente cliente){    
        return cDAO.buscarClientes(cliente);
    }
    
    public List<Cliente> listarClientes() {
        return cDAO.listarTodos();
    }

    
}
