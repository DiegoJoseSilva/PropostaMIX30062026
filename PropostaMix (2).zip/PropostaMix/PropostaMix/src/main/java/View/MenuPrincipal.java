package View;


public class MenuPrincipal extends javax.swing.JFrame {

   
    public MenuPrincipal() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        MenuPrincipal = new javax.swing.JMenuBar();
        MenuCadastro = new javax.swing.JMenu();
        menuCliente = new javax.swing.JMenuItem();
        menuEvento = new javax.swing.JMenuItem();
        menuItem = new javax.swing.JMenuItem();
        menuComercial = new javax.swing.JMenu();
        menuOrcamento = new javax.swing.JMenuItem();
        menuRelatorios = new javax.swing.JMenu();
        MenuFluxoCaixa = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        jMenuItem2.setText("jMenuItem2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        MenuPrincipal.setBackground(new java.awt.Color(204, 255, 255));
        MenuPrincipal.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Proposta MIX", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        MenuCadastro.setText("Cadastro");
        MenuCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuCadastroActionPerformed(evt);
            }
        });

        menuCliente.setText("Cliente");
        menuCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuClienteActionPerformed(evt);
            }
        });
        MenuCadastro.add(menuCliente);

        menuEvento.setText("Evento");
        menuEvento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuEventoActionPerformed(evt);
            }
        });
        MenuCadastro.add(menuEvento);

        menuItem.setText("Item");
        menuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemActionPerformed(evt);
            }
        });
        MenuCadastro.add(menuItem);

        MenuPrincipal.add(MenuCadastro);

        menuComercial.setText("Comercial");
        menuComercial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuComercialActionPerformed(evt);
            }
        });

        menuOrcamento.setText("Orçamentos/Contratos");
        menuOrcamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuOrcamentoActionPerformed(evt);
            }
        });
        menuComercial.add(menuOrcamento);

        MenuPrincipal.add(menuComercial);

        menuRelatorios.setText("Relatórios");

        MenuFluxoCaixa.setText("Fluxo de caixa");
        MenuFluxoCaixa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuFluxoCaixaActionPerformed(evt);
            }
        });
        menuRelatorios.add(MenuFluxoCaixa);

        MenuPrincipal.add(menuRelatorios);

        setJMenuBar(MenuPrincipal);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuCadastroActionPerformed
            
    }//GEN-LAST:event_MenuCadastroActionPerformed

    private void menuComercialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuComercialActionPerformed
           
    }//GEN-LAST:event_menuComercialActionPerformed

    private void menuClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuClienteActionPerformed
        TelaCliente tela = new TelaCliente();
        tela.setVisible(true);
    }//GEN-LAST:event_menuClienteActionPerformed

    private void menuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemActionPerformed
         TelaItens tela = new TelaItens();
        tela.setVisible(true);
    }//GEN-LAST:event_menuItemActionPerformed

    private void menuOrcamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuOrcamentoActionPerformed
        TelaOrcamentos tela = new TelaOrcamentos();
        tela.setVisible(true);
    }//GEN-LAST:event_menuOrcamentoActionPerformed

    private void menuEventoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuEventoActionPerformed
        TelaEvento tela = new TelaEvento();
        tela.setVisible(true);
    }//GEN-LAST:event_menuEventoActionPerformed

    private void MenuFluxoCaixaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuFluxoCaixaActionPerformed
       TelaFluxoCaixa tela = new TelaFluxoCaixa();
       tela.setVisible(true);
    }//GEN-LAST:event_MenuFluxoCaixaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu MenuCadastro;
    private javax.swing.JMenuItem MenuFluxoCaixa;
    private javax.swing.JMenuBar MenuPrincipal;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem menuCliente;
    private javax.swing.JMenu menuComercial;
    private javax.swing.JMenuItem menuEvento;
    private javax.swing.JMenuItem menuItem;
    private javax.swing.JMenuItem menuOrcamento;
    private javax.swing.JMenu menuRelatorios;
    // End of variables declaration//GEN-END:variables
}
